package com.example.demo.domain.claim;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ClaimTest {

    @Test
    void shouldCreateValidClaim() {
        UUID claimId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();

        Claim claim = new Claim(
            claimId,
            userId,
            LocalDate.now().minusDays(5),
            "Sydney NSW",
            "The car was damaged when another vehicle crossed into our lane.",
            new BigDecimal("2500.00")
        );

        assertThat(claim.getClaimId()).isEqualTo(claimId);
        assertThat(claim.getUserId()).isEqualTo(userId);
        assertThat(claim.getStatus()).isEqualTo(ClaimStatus.SUBMITTED);
        assertThat(claim.getDomainEvents()).hasSize(1);
    }

    @Test
    void shouldRejectFutureIncidentDate() {
        assertThatThrownBy(() -> new Claim(
            UUID.randomUUID(),
            UUID.randomUUID(),
            LocalDate.now().plusDays(1),
            "Melbourne VIC",
            "The vehicle struck a pothole and the tyre was damaged.",
            new BigDecimal("1000")
        ))
            .isInstanceOf(InvalidClaimException.class)
            .hasMessageContaining("future");
    }

    @Test
    void shouldRejectInvalidAmounts() {
        assertThatThrownBy(() -> new Claim(
            UUID.randomUUID(),
            UUID.randomUUID(),
            LocalDate.now().minusDays(4),
            "Perth WA",
            "The fence was damaged after a storm moved through the area.",
            BigDecimal.ZERO
        ))
            .isInstanceOf(InvalidClaimException.class)
            .hasMessageContaining("positive");

        assertThatThrownBy(() -> new Claim(
            UUID.randomUUID(),
            UUID.randomUUID(),
            LocalDate.now().minusDays(4),
            "Perth WA",
            "The fence was damaged after a storm moved through the area.",
            new BigDecimal("1000001")
        ))
            .isInstanceOf(InvalidClaimException.class)
            .hasMessageContaining("1,000,000");
    }

    @Test
    void shouldAllowExpectedStatusTransitions() {
        Claim claim = new Claim(
            UUID.randomUUID(),
            UUID.randomUUID(),
            LocalDate.now().minusDays(10),
            "Brisbane QLD",
            "The claim relates to a vehicle impact that occurred in a parking lot.",
            new BigDecimal("6000")
        );

        claim.updateStatus(ClaimStatus.UNDER_REVIEW);
        assertThat(claim.getStatus()).isEqualTo(ClaimStatus.UNDER_REVIEW);

        claim.updateStatus(ClaimStatus.APPROVED);
        assertThat(claim.getStatus()).isEqualTo(ClaimStatus.APPROVED);

        claim.updateStatus(ClaimStatus.CLOSED);
        assertThat(claim.getStatus()).isEqualTo(ClaimStatus.CLOSED);
    }

    @Test
    void shouldRejectInvalidStatusTransitions() {
        Claim claim = new Claim(
            UUID.randomUUID(),
            UUID.randomUUID(),
            LocalDate.now().minusDays(2),
            "Adelaide SA",
            "Damage occurred to the vehicle bonnet after a collision at a junction.",
            new BigDecimal("2000")
        );

        assertThatThrownBy(() -> claim.updateStatus(ClaimStatus.APPROVED))
            .isInstanceOf(InvalidStatusTransitionException.class)
            .hasMessageContaining("Cannot transition from SUBMITTED to APPROVED");

        claim.updateStatus(ClaimStatus.UNDER_REVIEW);
        assertThatThrownBy(() -> claim.updateStatus(ClaimStatus.CLOSED))
            .isInstanceOf(InvalidStatusTransitionException.class)
            .hasMessageContaining("UNDER_REVIEW to CLOSED");
    }
}
