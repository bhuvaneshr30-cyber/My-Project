package com.example.demo.application.usecases;

import com.example.demo.domain.claim.Claim;
import com.example.demo.domain.claim.ClaimRepository;
import com.example.demo.domain.claim.ClaimStatus;
import com.example.demo.domain.claim.InvalidStatusTransitionException;
import com.example.demo.user.domain.Email;
import com.example.demo.user.domain.UnauthorizedException;
import com.example.demo.user.domain.User;
import com.example.demo.user.domain.UserId;
import com.example.demo.user.domain.UserRepository;
import com.example.demo.user.domain.UserRole;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationEventPublisher;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class UpdateClaimStatusUseCaseTest {

    @Test
    void shouldAllowAdminToUpdateClaimStatus() {
        ClaimRepository claimRepository = mock(ClaimRepository.class);
        UserRepository userRepository = mock(UserRepository.class);
        ApplicationEventPublisher eventPublisher = mock(ApplicationEventPublisher.class);

        UUID adminId = UUID.randomUUID();
        UUID claimId = UUID.randomUUID();

        User admin = new User(UserId.of(adminId), "System Admin", new Email("admin@demo.com"), UserRole.ADMIN, Instant.now());
        Claim claim = new Claim(
            claimId,
            UUID.randomUUID(),
            LocalDate.now().minusDays(4),
            "Brisbane QLD",
            "Vehicle damage occurred to the rear bumper after a collision.",
            new BigDecimal("4200.00")
        );

        when(userRepository.findById(UserId.of(adminId))).thenReturn(Optional.of(admin));
        when(claimRepository.findById(claimId)).thenReturn(Optional.of(claim));
        when(claimRepository.save(claim)).thenReturn(claim);

        UpdateClaimStatusUseCase useCase = new UpdateClaimStatusUseCase(
            claimRepository,
            userRepository,
            new SimpleMeterRegistry(),
            eventPublisher
        );
        setCdcEnabled(useCase, false);

        Claim updated = useCase.execute(new UpdateClaimStatusCommand(claimId, ClaimStatus.UNDER_REVIEW, adminId));

        assertThat(updated.getStatus()).isEqualTo(ClaimStatus.UNDER_REVIEW);
        verify(eventPublisher, times(2)).publishEvent(org.mockito.ArgumentMatchers.any());
    }

    @Test
    void shouldRejectNonAdminUsers() {
        ClaimRepository claimRepository = mock(ClaimRepository.class);
        UserRepository userRepository = mock(UserRepository.class);
        ApplicationEventPublisher eventPublisher = mock(ApplicationEventPublisher.class);

        UUID claimantId = UUID.randomUUID();
        UUID claimId = UUID.randomUUID();

        User claimant = new User(UserId.of(claimantId), "Jane Claimant", new Email("claimant@demo.com"), UserRole.CLAIMANT, Instant.now());
        Claim claim = new Claim(
            claimId,
            claimantId,
            LocalDate.now().minusDays(6),
            "Adelaide SA",
            "A parked vehicle was struck in a supermarket car park.",
            new BigDecimal("1500.00")
        );

        when(userRepository.findById(UserId.of(claimantId))).thenReturn(Optional.of(claimant));
        when(claimRepository.findById(claimId)).thenReturn(Optional.of(claim));

        UpdateClaimStatusUseCase useCase = new UpdateClaimStatusUseCase(
            claimRepository,
            userRepository,
            new SimpleMeterRegistry(),
            eventPublisher
        );

        assertThatThrownBy(() -> useCase.execute(new UpdateClaimStatusCommand(claimId, ClaimStatus.UNDER_REVIEW, claimantId)))
            .isInstanceOf(UnauthorizedException.class)
            .hasMessageContaining("Only admin users can update claim status");
    }

    private static void setCdcEnabled(UpdateClaimStatusUseCase useCase, boolean enabled) {
        try {
            Field field = UpdateClaimStatusUseCase.class.getDeclaredField("cdcEnabled");
            field.setAccessible(true);
            field.setBoolean(useCase, enabled);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("Failed to configure CDC flag in test", e);
        }
    }

    @Test
    void shouldRejectInvalidStatusTransitions() {
        ClaimRepository claimRepository = mock(ClaimRepository.class);
        UserRepository userRepository = mock(UserRepository.class);
        ApplicationEventPublisher eventPublisher = mock(ApplicationEventPublisher.class);

        UUID adminId = UUID.randomUUID();
        UUID claimId = UUID.randomUUID();

        User admin = new User(UserId.of(adminId), "System Admin", new Email("admin@demo.com"), UserRole.ADMIN, Instant.now());
        Claim claim = new Claim(
            claimId,
            UUID.randomUUID(),
            LocalDate.now().minusDays(8),
            "Sydney NSW",
            "The claim involves a damaged roof panel after a storm.",
            new BigDecimal("8750.00")
        );

        when(userRepository.findById(UserId.of(adminId))).thenReturn(Optional.of(admin));
        when(claimRepository.findById(claimId)).thenReturn(Optional.of(claim));

        UpdateClaimStatusUseCase useCase = new UpdateClaimStatusUseCase(
            claimRepository,
            userRepository,
            new SimpleMeterRegistry(),
            eventPublisher
        );

        assertThatThrownBy(() -> useCase.execute(new UpdateClaimStatusCommand(claimId, ClaimStatus.APPROVED, adminId)))
            .isInstanceOf(InvalidStatusTransitionException.class)
            .hasMessageContaining("Cannot transition from SUBMITTED to APPROVED");
    }
}
