import { describe, expect, it } from 'vitest';

import { STATUS_LABELS, VALID_TRANSITIONS, getValidTransitions } from './claim-status-transitions';

describe('claim status transitions', () => {
  it('allows the expected transitions for a newly submitted claim', () => {
    expect(getValidTransitions('SUBMITTED' as any)).toEqual(['UNDER_REVIEW', 'REJECTED']);
    expect(VALID_TRANSITIONS.SUBMITTED).toEqual(['UNDER_REVIEW', 'REJECTED']);
  });

  it('keeps admin review options aligned with the domain workflow', () => {
    expect(getValidTransitions('UNDER_REVIEW' as any)).toEqual(['APPROVED', 'REJECTED', 'SUBMITTED']);
    expect(STATUS_LABELS.UNDER_REVIEW).toBe('Under Review');
    expect(STATUS_LABELS.CLOSED).toBe('Closed');
  });
});
