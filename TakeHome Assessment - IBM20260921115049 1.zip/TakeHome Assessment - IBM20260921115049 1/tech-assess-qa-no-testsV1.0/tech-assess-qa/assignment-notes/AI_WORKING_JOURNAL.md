# AI Working Journal

## Prompt and review flow

1. Reviewed the assessment brief and the app architecture to identify the highest-risk business and UX areas.
2. Prioritized claim lifecycle logic, role enforcement, and real-time event processing as the most valuable testing targets.
3. Used the domain model and admin status use case as the primary test anchors, because those are the places where correctness and security matter most.
4. Validated the app’s frontend route guard and transition metadata as supporting checks without overinvesting in low-yield UI breadth.

## Decisions accepted

- Used JUnit 5 + AssertJ for the backend domain/unit tests because the app is already Spring Boot based and the rules are concentrated in the domain model.
- Kept the tests close to business behavior instead of implementation details, which makes the suite easier to defend in a walkthrough.
- Treated route protection as a UX guard and called out the security limitation explicitly in the notes.

## Decisions challenged or overridden

- The project README suggests the app is set up for QA work, but the codebase did not include a ready-made test suite for the core flows. I chose to add targeted, business-facing coverage rather than chasing every layer.
- I did not expand into a broad Kafka or Debezium suite because the stack is not available in this environment and the risk-based assessment prioritized claim logic and authorization first.
- I deliberately did not treat the frontend middleware as a true security boundary; I documented it as a concern instead of pretending it was equivalent to server-side enforcement.

## Outcome

The final work focuses on the highest-value proof points: valid claim creation, invalid business transitions, protected admin status updates, and a small frontend transition guard that reflects the same workflow rules.
