# Test Strategy and Risk Assessment

## Overview
This assessment is designed as a QA exercise for a multi-service insurance claims demo. The application includes a Next.js UI, a BFF (Spring Boot), a claims service (Spring Boot), PostgreSQL, Kafka, Redis, and Keycloak. The goal is not just to run the app, but to identify high-risk areas, test the most business-critical flows, and document coverage gaps and defects.

## Highest-risk areas identified

### 1) Claim status transition logic
Risk: High
Why: This is the core business rule of the application. Invalid transitions can create inconsistent or impossible claim states and break auditability.
Evidence: The domain model enforces transitions in `Claim.updateStatus()` and throws `InvalidStatusTransitionException` when a transition is invalid.
Test focus:
- valid transitions from `SUBMITTED -> UNDER_REVIEW`
- valid transitions from `UNDER_REVIEW -> APPROVED|REJECTED`
- invalid transitions such as `APPROVED -> SUBMITTED`
- duplicate or repeated update attempts
- boundary tests at status transition edges

### 2) Claim creation validation and input integrity
Risk: High
Why: Invalid claims may be accepted if field validation is weak. This can corrupt domain data and affect downstream reporting and Kafka events.
Evidence: `Claim` constructor validates: description length, incident location length, future incident dates, claim amount positivity/upper bound.
Test focus:
- invalid negative amount
- zero amount
- extremely large amount
- future incident dates
- too-short or too-long descriptions
- blank incident location

### 3) Authorization and role enforcement
Risk: High
Why: The app has admin and claimant roles, and unauthorized updates are a serious security and business risk.
Evidence: `UpdateClaimStatusUseCase` checks `admin.getRole() != UserRole.ADMIN` before allowing updates. The BFF and claims service use `@PreAuthorize` on controllers.
Test focus:
- claimant attempts to update status
- unauthenticated access attempts
- token/cookie missing or stale scenarios
- admin-only endpoints expected to reject non-admin users

### 4) Event-driven behavior and real-time updates
Risk: Medium-High
Why: The app uses Kafka and WebSocket flows, which increases complexity and failure modes. If events are lost, duplicated, or emitted incorrectly, the UI will show stale or wrong claim status information.
Evidence: domain event publishing occurs in the claims service and the UI listens for status change notifications.
Test focus:
- event emission on claim submission and status updates
- duplicate event prevention
- event payload correctness
- WebSocket notification delivery on status change

### 5) Frontend route protection and session handling
Risk: Medium
Why: The middleware does a cookie existence check but does not validate tokens itself. This creates a UX-only guard, not a true security control.
Evidence: `demo-app-ui/middleware.ts` checks for access_token or refresh_token existence and redirects if absent.
Test focus:
- protected routes redirect unauthenticated users
- authenticated sessions keep access
- stale refresh-token behavior

## What I chose to test
Given the assignment scope and the need to prioritize high-value QA coverage, I focused on the most business-critical flows:

1. Domain-level validation tests for claim creation and status updates
2. Authorization tests for admin-only status changes
3. Invalid state transition tests for claim workflow integrity
4. API contract and validation tests around claim submission and admin updates
5. Frontend route protection / session redirect checks
6. A risk-based review of event-driven interactions and middleware behavior

## What I deliberately skipped
These were deprioritized for this assessment because they are lower-yield unless the app is already stable and the core flows are proven:

- exhaustive load testing of Kafka or DB under high scale
- broad UI visual regression testing across every screen
- deep Debezium CDC configuration validation without the stack running
- long-running performance benchmarking with large data volumes
- full security penetration testing beyond the obvious role-based checks

## Observations and concerns found during review

### Concern 1: UI middleware is not a real security boundary
The frontend middleware only checks for cookie existence. This helps with UX, but does not enforce authentication or authorization. Real validation must remain server-side.

### Concern 2: Critical business logic is concentrated in the domain model
This is a strength from a design standpoint because the rules are centralized, but it also means a small bug in transitions or validation could affect many workflows.

### Concern 3: Event-driven systems add operational risk
Kafka + CDC + WebSockets create multiple places where messages may be lost, delayed, or duplicated. Even if the app works in one mode, cross-service failure paths need QA attention.

### Concern 4: The assignment README explicitly calls out a known broken test
The repo states there is a broken test as a starting point. That indicates the codebase is intentionally set up to require QA intervention, not a green baseline.

## Suggested test priorities for follow-up
1. Fix and expand domain unit tests
2. Add integration tests with Testcontainers for claims workflow
3. Add contract tests between BFF and claims-service
4. Add Playwright E2E for login and claim lifecycle
5. Add manual regression checklist for admin claim status updates

## Conclusion
The highest-value testing area is the claim lifecycle: creation, validation, status transitions, authorization, and event propagation. This is where business correctness and user trust are most likely to break if the app is not tested carefully.
