# QA Notes

## Scope
This notes document captures the assessment review for the demo insurance claims application. The objective is to identify high-risk testing areas, document the reasoning behind the chosen coverage, and note concerns discovered during code review.

## High-risk area review

### Business logic risk
The claim workflow is central to the app. A wrong status transition or validation bug can corrupt the claim lifecycle and produce inaccurate operational reports.

### Security risk
The app includes admin-only actions and token-based authentication, so testing the boundary between claimant and admin behavior is essential.

### Integration risk
The app has multiple moving parts: PostgreSQL, Kafka, Redis, Keycloak, UI, BFF, and claims service. Failures can appear as stale UI data, invalid status updates, or broken auth flows.

## Selected tests for this assessment
- claim creation validation
- invalid claim amount checks
- future incident date rejection
- status transition validation
- admin-only status update enforcement
- redirect behavior for protected frontend routes without auth
- event emission consistency around claim change operations

## Deliberately not prioritized
- benchmark testing with large synthetic datasets
- schema migration or database performance tuning beyond the app flow
- all possible edge-case permutations across every microservice
- end-to-end CDC test mode until the local stacked environment is healthy

## Code and review concerns
1. The frontend auth guard is not a true security layer and should not be treated as the primary safeguard.
2. Event-driven messaging creates risk of hidden data inconsistencies if not continuously tested.
3. The repo explicitly notes a known broken test, which suggests the original baseline is intentionally incomplete and should not be treated as a reliable release gate.
4. Risk-based QA should focus on business-critical flows before broad test automation coverage.

## Recommendation
Focus first on the domain and workflow tests, then add service-to-service integration and end-to-end coverage once the environment is stable. The main goal is to validate real end-user business flows and security boundaries rather than generating volume for volume’s sake.
